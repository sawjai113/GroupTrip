import { useState } from 'react';
import { Box, Typography, Button, Container, Grid, Collapse, IconButton } from '@mui/material';
import { Plus, Plane, ChevronDown, ChevronUp } from 'lucide-react';
import { TripCard } from './components/TripCard';
import { FeaturedTripsCarousel } from './components/FeaturedTripsCarousel';
import { CreateTripDialog } from './components/CreateTripDialog';
import { TripSummary } from './components/TripSummary';
import { TripDetail } from './components/TripDetail';
import { toast, Toaster } from 'sonner';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

const sampleTrips: Trip[] = [
  {
    id: '1',
    name: 'Iceland Adventure',
    destination: 'Reykjavik, Iceland',
    startDate: '2026-05-10',
    endDate: '2026-05-20',
    participants: ['Alice', 'Bob', 'Charlie'],
    totalExpenses: 4250.50,
    imageUrl: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=800'
  },
  {
    id: '2',
    name: 'Tokyo Summer Trip',
    destination: 'Tokyo, Japan',
    startDate: '2026-07-01',
    endDate: '2026-07-14',
    participants: ['David', 'Emma'],
    totalExpenses: 1200.00,
    imageUrl: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800'
  },
  {
    id: '3',
    name: 'Paris Weekend',
    destination: 'Paris, France',
    startDate: '2026-08-20',
    endDate: '2026-08-25',
    participants: ['Alice', 'Frank', 'Grace'],
    totalExpenses: 850.00,
    imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800'
  },
  {
    id: '4',
    name: 'Barcelona Getaway',
    destination: 'Barcelona, Spain',
    startDate: '2026-03-10',
    endDate: '2026-03-17',
    participants: ['David', 'Emma'],
    totalExpenses: 2450.00,
    imageUrl: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800'
  },
  {
    id: '5',
    name: 'Thailand Beach Trip',
    destination: 'Phuket, Thailand',
    startDate: '2025-12-20',
    endDate: '2026-01-05',
    participants: ['Alice', 'Frank', 'Grace'],
    totalExpenses: 3890.75,
    imageUrl: 'https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=800'
  }
];

const sampleExpenses: Record<string, Expense[]> = {
  '1': [
    {
      id: 'e1',
      description: 'Hotel booking',
      amount: 1200.00,
      paidBy: 'Alice',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Accommodation',
      date: '2026-06-15'
    },
    {
      id: 'e2',
      description: 'Sushi dinner',
      amount: 180.50,
      paidBy: 'Bob',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Food',
      date: '2026-06-16'
    },
    {
      id: 'e3',
      description: 'Train tickets to Kyoto',
      amount: 270.00,
      paidBy: 'Charlie',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Transportation',
      date: '2026-06-18'
    }
  ],
  '2': [
    {
      id: 'e4',
      description: 'Airbnb',
      amount: 1500.00,
      paidBy: 'David',
      splitAmong: ['David', 'Emma'],
      category: 'Accommodation',
      date: '2026-07-01'
    }
  ]
};

type ViewMode = 'list' | 'summary' | 'expenses';

export default function App() {
  const [trips, setTrips] = useState<Trip[]>(sampleTrips);
  const [expenses, setExpenses] = useState<Record<string, Expense[]>>(sampleExpenses);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedTripId, setSelectedTripId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [pastTripsOpen, setPastTripsOpen] = useState(false);

  const selectedTrip = trips.find(t => t.id === selectedTripId);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sortedTrips = [...trips].sort((a, b) =>
    new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
  );

  const currentTrip = sortedTrips.find(trip =>
    new Date(trip.startDate) <= today && new Date(trip.endDate) >= today
  );

  const allFutureTrips = sortedTrips.filter(trip => new Date(trip.startDate) > today);

  const featuredTrips = currentTrip ? [currentTrip, ...allFutureTrips] : allFutureTrips;

  const pastTrips = sortedTrips.filter(trip => new Date(trip.endDate) < today).reverse();

  const handleCreateTrip = (tripData: {
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    imageUrl: string;
  }) => {
    const newTrip: Trip = {
      id: Date.now().toString(),
      ...tripData,
      participants: [],
      totalExpenses: 0
    };
    setTrips([...trips, newTrip]);
    setExpenses({ ...expenses, [newTrip.id]: [] });
  };

  const handleAddExpense = (tripId: string, expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      id: Date.now().toString(),
      ...expenseData
    };

    const tripExpenses = [...(expenses[tripId] || []), newExpense];
    setExpenses({ ...expenses, [tripId]: tripExpenses });

    const totalExpenses = tripExpenses.reduce((sum, e) => sum + e.amount, 0);
    setTrips(trips.map(t =>
      t.id === tripId ? { ...t, totalExpenses } : t
    ));
  };

  const handleDeleteExpense = (tripId: string, expenseId: string) => {
    const tripExpenses = expenses[tripId].filter(e => e.id !== expenseId);
    setExpenses({ ...expenses, [tripId]: tripExpenses });

    const totalExpenses = tripExpenses.reduce((sum, e) => sum + e.amount, 0);
    setTrips(trips.map(t =>
      t.id === tripId ? { ...t, totalExpenses } : t
    ));
  };

  const handleAddParticipant = (tripId: string, name: string) => {
    setTrips(trips.map(t =>
      t.id === tripId
        ? { ...t, participants: [...t.participants, name] }
        : t
    ));
  };

  const handleTripClick = (tripId: string) => {
    setSelectedTripId(tripId);
    setViewMode('summary');
  };

  const handleBackToList = () => {
    setSelectedTripId(null);
    setViewMode('list');
  };

  const handleBackToSummary = () => {
    setViewMode('summary');
  };

  const handleFeatureNotReady = (featureName: string) => {
    toast.info(`${featureName} coming soon!`);
  };

  if (selectedTrip && viewMode === 'summary') {
    return (
      <TripSummary
        trip={selectedTrip}
        onBack={handleBackToList}
        onOpenExpenses={() => setViewMode('expenses')}
        onInviteParticipants={() => handleFeatureNotReady('Invite Participants')}
        onOpenChat={() => handleFeatureNotReady('Trip Chat')}
        onOpenInterests={() => handleFeatureNotReady('Places & Interests')}
        onOpenCalendar={() => handleFeatureNotReady('Itinerary')}
        onOpenMap={() => handleFeatureNotReady('Map View')}
      />
    );
  }

  if (selectedTrip && viewMode === 'expenses') {
    return (
      <TripDetail
        trip={selectedTrip}
        expenses={expenses[selectedTrip.id] || []}
        onBack={handleBackToSummary}
        onAddExpense={(expense) => handleAddExpense(selectedTrip.id, expense)}
        onAddParticipant={(name) => handleAddParticipant(selectedTrip.id, name)}
        onDeleteExpense={(expenseId) => handleDeleteExpense(selectedTrip.id, expenseId)}
      />
    );
  }

  return (
    <>
      <Toaster position="top-center" />
      <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', pb: 2 }}>
        <Box sx={{
          position: 'sticky',
          top: 0,
          bgcolor: 'background.paper',
          zIndex: 10,
          borderBottom: '1px solid',
          borderColor: 'divider',
          px: 2,
          py: 2
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Plane size={28} color="#1976d2" />
              <Typography variant="h5">TravelSplit</Typography>
            </Box>
            <Button
              variant="contained"
              size="small"
              startIcon={<Plus size={18} />}
              onClick={() => setCreateDialogOpen(true)}
            >
              New
            </Button>
          </Box>
          <Typography variant="body2" color="text.secondary">
            Track expenses with friends
          </Typography>
        </Box>

        <Box sx={{ px: 2, pt: 2 }}>

        {trips.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Plane size={64} color="#ccc" style={{ marginBottom: 16 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No trips yet
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Create your first trip to start tracking expenses
            </Typography>
            <Button
              variant="contained"
              startIcon={<Plus size={20} />}
              onClick={() => setCreateDialogOpen(true)}
            >
              Create Your First Trip
            </Button>
          </Box>
        ) : (
          <Box>
            {featuredTrips.length > 0 && (
              <FeaturedTripsCarousel
                trips={featuredTrips}
                onTripClick={handleTripClick}
              />
            )}

            {pastTrips.length > 0 && (
              <Box>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    mb: 2,
                    cursor: 'pointer',
                    py: 1,
                    '&:active': { opacity: 0.7 }
                  }}
                  onClick={() => setPastTripsOpen(!pastTripsOpen)}
                >
                  <Typography variant="h6">Past Trips</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Typography variant="body2" color="text.secondary">{pastTrips.length}</Typography>
                    <IconButton size="small">
                      {pastTripsOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </IconButton>
                  </Box>
                </Box>

                <Collapse in={pastTripsOpen}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {pastTrips.map(trip => (
                      <TripCard key={trip.id} trip={trip} onClick={() => handleTripClick(trip.id)} />
                    ))}
                  </Box>
                </Collapse>
              </Box>
            )}

            {featuredTrips.length === 0 && pastTrips.length === 0 && (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="body1" color="text.secondary">
                  All your trips are in the past. Create a new one!
                </Typography>
              </Box>
            )}
          </Box>
        )}

        <CreateTripDialog
          open={createDialogOpen}
          onClose={() => setCreateDialogOpen(false)}
          onCreateTrip={handleCreateTrip}
        />
        </Box>
      </Box>
    </>
  );
}