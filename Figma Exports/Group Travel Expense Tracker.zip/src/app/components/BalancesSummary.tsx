import { Card, CardContent, Typography, Box, Avatar, Divider, Chip } from '@mui/material';
import { ArrowRight, CheckCircle } from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface BalancesSummaryProps {
  expenses: Expense[];
  participants: string[];
}

interface Balance {
  person: string;
  balance: number;
}

interface Settlement {
  from: string;
  to: string;
  amount: number;
}

function calculateBalances(expenses: Expense[], participants: string[]): Balance[] {
  const balances: Record<string, number> = {};

  participants.forEach(p => {
    balances[p] = 0;
  });

  expenses.forEach(expense => {
    const sharePerPerson = expense.amount / expense.splitAmong.length;

    balances[expense.paidBy] += expense.amount;

    expense.splitAmong.forEach(person => {
      balances[person] -= sharePerPerson;
    });
  });

  return Object.entries(balances).map(([person, balance]) => ({
    person,
    balance
  }));
}

function calculateSettlements(balances: Balance[]): Settlement[] {
  const settlements: Settlement[] = [];
  const debts = balances.filter(b => b.balance < -0.01).map(b => ({ ...b }));
  const credits = balances.filter(b => b.balance > 0.01).map(b => ({ ...b }));

  let debtIndex = 0;
  let creditIndex = 0;

  while (debtIndex < debts.length && creditIndex < credits.length) {
    const debt = debts[debtIndex];
    const credit = credits[creditIndex];
    const amount = Math.min(-debt.balance, credit.balance);

    if (amount > 0.01) {
      settlements.push({
        from: debt.person,
        to: credit.person,
        amount
      });
    }

    debt.balance += amount;
    credit.balance -= amount;

    if (Math.abs(debt.balance) < 0.01) debtIndex++;
    if (Math.abs(credit.balance) < 0.01) creditIndex++;
  }

  return settlements;
}

export function BalancesSummary({ expenses, participants }: BalancesSummaryProps) {
  const balances = calculateBalances(expenses, participants);
  const settlements = calculateSettlements(balances);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Card sx={{ borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="body1" sx={{ fontWeight: 600, mb: 1.5 }}>
            Individual Balances
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {balances.map((balance, index) => (
              <Box key={balance.person} sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Avatar sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)`, width: 36, height: 36 }}>
                  {balance.person[0].toUpperCase()}
                </Avatar>
                <Typography variant="body2" sx={{ flex: 1 }}>
                  {balance.person}
                </Typography>
                <Chip
                  label={`${balance.balance >= 0 ? '+' : ''}$${balance.balance.toFixed(2)}`}
                  color={balance.balance > 0.01 ? 'success' : balance.balance < -0.01 ? 'error' : 'default'}
                  size="small"
                  sx={{ minWidth: 90, fontWeight: 600 }}
                />
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>

      <Card sx={{ borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="body1" sx={{ fontWeight: 600, mb: 1.5 }}>
            Suggested Settlements
          </Typography>
          {settlements.length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <CheckCircle size={40} color="#4caf50" style={{ marginBottom: 12 }} />
              <Typography variant="body2" color="text.secondary">
                All settled up!
              </Typography>
            </Box>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              {settlements.map((settlement, index) => {
                const fromIndex = participants.indexOf(settlement.from);
                const toIndex = participants.indexOf(settlement.to);

                return (
                  <Card key={index} variant="outlined" sx={{ bgcolor: 'action.hover', borderRadius: 1.5 }}>
                    <CardContent sx={{ p: 1.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Avatar sx={{ bgcolor: `hsl(${fromIndex * 60}, 70%, 50%)`, width: 32, height: 32, fontSize: '0.875rem' }}>
                          {settlement.from[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2" sx={{ minWidth: 0, flex: '0 0 auto' }}>{settlement.from}</Typography>
                        <ArrowRight size={18} style={{ flexShrink: 0 }} />
                        <Avatar sx={{ bgcolor: `hsl(${toIndex * 60}, 70%, 50%)`, width: 32, height: 32, fontSize: '0.875rem' }}>
                          {settlement.to[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }}>{settlement.to}</Typography>
                        <Chip
                          label={`$${settlement.amount.toFixed(2)}`}
                          color="primary"
                          size="small"
                          sx={{ minWidth: 75, fontWeight: 600 }}
                        />
                      </Box>
                    </CardContent>
                  </Card>
                );
              })}
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
