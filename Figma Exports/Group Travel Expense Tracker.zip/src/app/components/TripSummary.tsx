import { Box, Typography, IconButton, Avatar, AvatarGroup, Card, CardContent, CardMedia } from '@mui/material';
import {
  ArrowLeft,
  UserPlus,
  MessageCircle,
  MapPin,
  Calendar as CalendarIcon,
  Map,
  Receipt,
  ChevronRight
} from 'lucide-react';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface TripSummaryProps {
  trip: Trip;
  onBack: () => void;
  onOpenExpenses: () => void;
  onInviteParticipants: () => void;
  onOpenChat: () => void;
  onOpenInterests: () => void;
  onOpenCalendar: () => void;
  onOpenMap: () => void;
}

interface ActionCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  color?: string;
}

function ActionCard({ icon, title, description, onClick, color = '#1976d2' }: ActionCardProps) {
  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        borderRadius: 2
      }}
      onClick={onClick}
    >
      <CardContent sx={{ p: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              bgcolor: `${color}15`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}
          >
            {icon}
          </Box>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="body1" sx={{ fontWeight: 600 }} gutterBottom>
              {title}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.85rem' }}>
              {description}
            </Typography>
          </Box>
          <ChevronRight size={20} color="#999" />
        </Box>
      </CardContent>
    </Card>
  );
}

export function TripSummary({
  trip,
  onBack,
  onOpenExpenses,
  onInviteParticipants,
  onOpenChat,
  onOpenInterests,
  onOpenCalendar,
  onOpenMap
}: TripSummaryProps) {
  const startDate = new Date(trip.startDate);
  const endDate = new Date(trip.endDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isUpcoming = startDate > today;
  const isOngoing = startDate <= today && endDate >= today;

  const formatDateRange = () => {
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric', year: 'numeric' };
    return `${startDate.toLocaleDateString('en-US', options)} - ${endDate.toLocaleDateString('en-US', options)}`;
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <Box sx={{ position: 'relative' }}>
        <CardMedia
          component="img"
          height="220"
          image={trip.imageUrl}
          alt={trip.name}
          sx={{ objectFit: 'cover' }}
        />
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            background: 'linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0) 100%)',
            p: 2
          }}
        >
          <IconButton
            onClick={onBack}
            sx={{
              bgcolor: 'rgba(255,255,255,0.9)',
              '&:hover': { bgcolor: 'white' }
            }}
          >
            <ArrowLeft size={24} />
          </IconButton>
        </Box>
      </Box>

      <Box sx={{ px: 2, pt: 2, pb: 3 }}>
        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 600, mb: 0.5 }}>
                {trip.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {trip.destination}
              </Typography>
            </Box>
            {(isOngoing || isUpcoming) && (
              <Box
                sx={{
                  bgcolor: isOngoing ? '#4caf50' : '#1976d2',
                  color: 'white',
                  px: 1.5,
                  py: 0.5,
                  borderRadius: 1,
                  fontSize: '0.75rem',
                  fontWeight: 600
                }}
              >
                {isOngoing ? 'NOW' : 'UPCOMING'}
              </Box>
            )}
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {formatDateRange()}
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <AvatarGroup max={5} sx={{ '& .MuiAvatar-root': { width: 32, height: 32, fontSize: '0.875rem' } }}>
              {trip.participants.map((participant, index) => (
                <Avatar key={participant} sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)` }}>
                  {participant[0].toUpperCase()}
                </Avatar>
              ))}
            </AvatarGroup>
            <Typography variant="body2" color="text.secondary">
              {trip.participants.length} {trip.participants.length === 1 ? 'traveler' : 'travelers'}
            </Typography>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <ActionCard
            icon={<Receipt size={24} color="#1976d2" />}
            title="Expenses"
            description={`Track and split costs • $${trip.totalExpenses.toFixed(2)} total`}
            onClick={onOpenExpenses}
            color="#1976d2"
          />

          <ActionCard
            icon={<UserPlus size={24} color="#9c27b0" />}
            title="Invite Participants"
            description="Add friends to your trip"
            onClick={onInviteParticipants}
            color="#9c27b0"
          />

          <ActionCard
            icon={<MessageCircle size={24} color="#2196f3" />}
            title="Trip Chat"
            description="Discuss plans with your group"
            onClick={onOpenChat}
            color="#2196f3"
          />

          <ActionCard
            icon={<MapPin size={24} color="#f44336" />}
            title="Places & Interests"
            description="Save restaurants, shops, and attractions"
            onClick={onOpenInterests}
            color="#f44336"
          />

          <ActionCard
            icon={<CalendarIcon size={24} color="#ff9800" />}
            title="Itinerary"
            description="Plan your daily schedule"
            onClick={onOpenCalendar}
            color="#ff9800"
          />

          <ActionCard
            icon={<Map size={24} color="#4caf50" />}
            title="Map View"
            description="See all your saved places on a map"
            onClick={onOpenMap}
            color="#4caf50"
          />
        </Box>
      </Box>
    </Box>
  );
}
