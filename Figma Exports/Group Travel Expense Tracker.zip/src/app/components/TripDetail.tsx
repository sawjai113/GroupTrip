import { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Tabs,
  Tab,
  Card,
  CardContent,
  IconButton,
  Chip,
  Avatar,
  AvatarGroup
} from '@mui/material';
import { ArrowLeft, Plus, Users, Receipt, TrendingUp } from 'lucide-react';
import { AddExpenseDialog } from './AddExpenseDialog';
import { AddParticipantDialog } from './AddParticipantDialog';
import { ExpenseList } from './ExpenseList';
import { BalancesSummary } from './BalancesSummary';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface TripDetailProps {
  trip: Trip;
  expenses: Expense[];
  onBack: () => void;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onAddParticipant: (name: string) => void;
  onDeleteExpense: (id: string) => void;
}

export function TripDetail({
  trip,
  expenses,
  onBack,
  onAddExpense,
  onAddParticipant,
  onDeleteExpense
}: TripDetailProps) {
  const [currentTab, setCurrentTab] = useState(0);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);
  const [participantDialogOpen, setParticipantDialogOpen] = useState(false);

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', pb: 2 }}>
      <Box sx={{
        position: 'sticky',
        top: 0,
        bgcolor: 'background.paper',
        zIndex: 10,
        borderBottom: '1px solid',
        borderColor: 'divider',
        px: 2,
        py: 1.5
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
          <IconButton onClick={onBack} size="small">
            <ArrowLeft size={24} />
          </IconButton>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="h6" noWrap>{trip.name}</Typography>
            <Typography variant="caption" color="text.secondary" noWrap>
              {trip.destination}
            </Typography>
          </Box>
          <AvatarGroup max={3} sx={{ '& .MuiAvatar-root': { width: 32, height: 32, fontSize: '0.875rem' } }}>
            {trip.participants.map((participant, index) => (
              <Avatar key={participant} sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)` }}>
                {participant[0].toUpperCase()}
              </Avatar>
            ))}
          </AvatarGroup>
        </Box>
      </Box>

      <Box sx={{ px: 2, pt: 2 }}>

      <Card sx={{ mb: 2, borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <Receipt size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">Total</Typography>
              <Typography variant="h6">${trip.totalExpenses.toFixed(0)}</Typography>
            </Box>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <Users size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">People</Typography>
              <Typography variant="h6">{trip.participants.length}</Typography>
            </Box>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <TrendingUp size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">Per Person</Typography>
              <Typography variant="h6">
                ${trip.participants.length > 0 ? (trip.totalExpenses / trip.participants.length).toFixed(0) : '0'}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs
          value={currentTab}
          onChange={(_, newValue) => setCurrentTab(newValue)}
          variant="fullWidth"
          sx={{ minHeight: 48 }}
        >
          <Tab label="Expenses" sx={{ minHeight: 48, py: 1 }} />
          <Tab label="Balances" sx={{ minHeight: 48, py: 1 }} />
          <Tab label="People" sx={{ minHeight: 48, py: 1 }} />
        </Tabs>
      </Box>

      {currentTab === 0 && (
        <Box>
          <Box sx={{ mb: 2 }}>
            <Button
              variant="contained"
              startIcon={<Plus size={18} />}
              onClick={() => setExpenseDialogOpen(true)}
              fullWidth
              sx={{ py: 1.5 }}
            >
              Add Expense
            </Button>
          </Box>
          <ExpenseList expenses={expenses} participants={trip.participants} onDelete={onDeleteExpense} />
        </Box>
      )}

      {currentTab === 1 && (
        <BalancesSummary expenses={expenses} participants={trip.participants} />
      )}

      {currentTab === 2 && (
        <Box>
          <Box sx={{ mb: 2 }}>
            <Button
              variant="contained"
              startIcon={<Plus size={18} />}
              onClick={() => setParticipantDialogOpen(true)}
              fullWidth
              sx={{ py: 1.5 }}
            >
              Add Participant
            </Button>
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {trip.participants.map((participant, index) => (
              <Card key={participant} sx={{ borderRadius: 2 }}>
                <CardContent sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Avatar sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)`, width: 48, height: 48 }}>
                      {participant[0].toUpperCase()}
                    </Avatar>
                    <Box>
                      <Typography variant="body1" sx={{ fontWeight: 600 }}>{participant}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {expenses.filter(e => e.paidBy === participant).length} expenses paid
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </Box>
        </Box>
      )}

      <AddExpenseDialog
        open={expenseDialogOpen}
        onClose={() => setExpenseDialogOpen(false)}
        participants={trip.participants}
        onAddExpense={onAddExpense}
      />

      <AddParticipantDialog
        open={participantDialogOpen}
        onClose={() => setParticipantDialogOpen(false)}
        onAddParticipant={onAddParticipant}
      />
      </Box>
    </Box>
  );
}
