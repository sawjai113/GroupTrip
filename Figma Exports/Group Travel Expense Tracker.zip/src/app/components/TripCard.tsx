import { Card, CardContent, CardMedia, Typography, Chip, Box } from '@mui/material';
import { Users, Calendar, DollarSign } from 'lucide-react';

interface TripCardProps {
  trip: {
    id: string;
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    participants: string[];
    totalExpenses: number;
    imageUrl: string;
  };
  onClick: () => void;
}

export function TripCard({ trip, onClick }: TripCardProps) {
  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        borderRadius: 2,
        display: 'flex',
        overflow: 'hidden'
      }}
      onClick={onClick}
    >
      <CardMedia
        component="img"
        sx={{ width: 120, height: 120, flexShrink: 0 }}
        image={trip.imageUrl}
        alt={trip.name}
      />
      <CardContent sx={{ flex: 1, p: 2 }}>
        <Typography variant="body1" sx={{ fontWeight: 600 }} gutterBottom>
          {trip.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" gutterBottom>
          {trip.destination}
        </Typography>

        <Box sx={{ display: 'flex', gap: 1, mt: 1.5, flexWrap: 'wrap' }}>
          <Chip
            icon={<Calendar size={14} />}
            label={new Date(trip.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
            size="small"
            variant="outlined"
          />
          <Chip
            icon={<Users size={14} />}
            label={trip.participants.length}
            size="small"
            variant="outlined"
          />
          <Chip
            icon={<DollarSign size={14} />}
            label={`$${trip.totalExpenses.toFixed(0)}`}
            size="small"
            color="primary"
            variant="outlined"
          />
        </Box>
      </CardContent>
    </Card>
  );
}
