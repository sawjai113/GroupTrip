import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  IconButton,
  Avatar,
  Divider
} from '@mui/material';
import { Trash2, Users } from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface ExpenseListProps {
  expenses: Expense[];
  participants: string[];
  onDelete: (id: string) => void;
}

const categoryColors: Record<string, string> = {
  Food: '#FF6B6B',
  Accommodation: '#4ECDC4',
  Transportation: '#45B7D1',
  Activities: '#FFA07A',
  Shopping: '#98D8C8',
  Other: '#95A5A6'
};

export function ExpenseList({ expenses, participants, onDelete }: ExpenseListProps) {
  if (expenses.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body1" color="text.secondary" textAlign="center" py={4}>
            No expenses yet. Add your first expense to get started!
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const sortedExpenses = [...expenses].sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
      {sortedExpenses.map((expense) => {
        const participantIndex = participants.indexOf(expense.paidBy);
        const avatarColor = `hsl(${participantIndex * 60}, 70%, 50%)`;

        return (
          <Card key={expense.id} sx={{ borderRadius: 2 }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                <Avatar sx={{ bgcolor: avatarColor, width: 40, height: 40 }}>
                  {expense.paidBy[0].toUpperCase()}
                </Avatar>

                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 0.5 }}>
                    <Box sx={{ flex: 1, minWidth: 0, mr: 1 }}>
                      <Typography variant="body1" sx={{ fontWeight: 600 }} noWrap>
                        {expense.description}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        {expense.paidBy} • {new Date(expense.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexShrink: 0 }}>
                      <Typography variant="body1" color="primary" sx={{ fontWeight: 600 }}>
                        ${expense.amount.toFixed(2)}
                      </Typography>
                      <IconButton size="small" onClick={() => onDelete(expense.id)} color="error">
                        <Trash2 size={16} />
                      </IconButton>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 1 }}>
                    <Chip
                      label={expense.category}
                      size="small"
                      sx={{
                        bgcolor: categoryColors[expense.category],
                        color: 'white',
                        height: 24,
                        fontSize: '0.7rem'
                      }}
                    />
                    <Chip
                      icon={<Users size={12} />}
                      label={`${expense.splitAmong.length} people`}
                      size="small"
                      variant="outlined"
                      sx={{ height: 24, fontSize: '0.7rem' }}
                    />
                    <Chip
                      label={`$${(expense.amount / expense.splitAmong.length).toFixed(2)} each`}
                      size="small"
                      variant="outlined"
                      sx={{ height: 24, fontSize: '0.7rem' }}
                    />
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        );
      })}
    </Box>
  );
}
