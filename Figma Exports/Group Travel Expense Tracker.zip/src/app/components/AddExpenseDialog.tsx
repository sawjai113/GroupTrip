import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  FormGroup,
  InputAdornment
} from '@mui/material';

interface AddExpenseDialogProps {
  open: boolean;
  onClose: () => void;
  participants: string[];
  onAddExpense: (expense: {
    description: string;
    amount: number;
    paidBy: string;
    splitAmong: string[];
    category: string;
    date: string;
  }) => void;
}

const categories = ['Food', 'Accommodation', 'Transportation', 'Activities', 'Shopping', 'Other'];

export function AddExpenseDialog({ open, onClose, participants, onAddExpense }: AddExpenseDialogProps) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paidBy, setPaidBy] = useState('');
  const [splitAmong, setSplitAmong] = useState<string[]>(participants);
  const [category, setCategory] = useState('Food');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleSubmit = () => {
    if (description && amount && paidBy && splitAmong.length > 0) {
      onAddExpense({
        description,
        amount: parseFloat(amount),
        paidBy,
        splitAmong,
        category,
        date
      });
      setDescription('');
      setAmount('');
      setPaidBy('');
      setSplitAmong(participants);
      setCategory('Food');
      setDate(new Date().toISOString().split('T')[0]);
      onClose();
    }
  };

  const handleToggleParticipant = (participant: string) => {
    if (splitAmong.includes(participant)) {
      setSplitAmong(splitAmong.filter(p => p !== participant));
    } else {
      setSplitAmong([...splitAmong, participant]);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Add Expense</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <TextField
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            fullWidth
            required
            placeholder="e.g., Dinner at restaurant"
          />

          <TextField
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            fullWidth
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>
            }}
          />

          <FormControl fullWidth required>
            <InputLabel>Category</InputLabel>
            <Select value={category} onChange={(e) => setCategory(e.target.value)} label="Category">
              {categories.map(cat => (
                <MenuItem key={cat} value={cat}>{cat}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            label="Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />

          <FormControl fullWidth required>
            <InputLabel>Paid By</InputLabel>
            <Select value={paidBy} onChange={(e) => setPaidBy(e.target.value)} label="Paid By">
              {participants.map(participant => (
                <MenuItem key={participant} value={participant}>{participant}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <Box>
            <InputLabel sx={{ mb: 1 }}>Split Among</InputLabel>
            <FormGroup>
              {participants.map(participant => (
                <FormControlLabel
                  key={participant}
                  control={
                    <Checkbox
                      checked={splitAmong.includes(participant)}
                      onChange={() => handleToggleParticipant(participant)}
                    />
                  }
                  label={participant}
                />
              ))}
            </FormGroup>
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Add Expense
        </Button>
      </DialogActions>
    </Dialog>
  );
}
