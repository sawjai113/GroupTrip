import { useRef } from 'react';
import { Box } from '@mui/material';
import Slider from 'react-slick';
import { FeaturedTripCard } from './FeaturedTripCard';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface FeaturedTripsCarouselProps {
  trips: Trip[];
  onTripClick: (tripId: string) => void;
}

export function FeaturedTripsCarousel({ trips, onTripClick }: FeaturedTripsCarouselProps) {
  const sliderRef = useRef<Slider>(null);

  if (trips.length === 0) return null;

  const settings = {
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    swipeToSlide: true,
    touchThreshold: 10,
    customPaging: () => (
      <div
        style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          backgroundColor: '#ccc',
          margin: '0 4px'
        }}
      />
    ),
    dotsClass: 'slick-dots custom-dots',
    appendDots: (dots: React.ReactNode) => (
      <Box
        sx={{
          position: 'relative',
          bottom: '-16px',
          '& li': {
            margin: '0 2px'
          },
          '& li.slick-active div': {
            backgroundColor: '#1976d2',
            width: '24px',
            borderRadius: '4px'
          }
        }}
      >
        <ul style={{ margin: 0, padding: 0, display: 'flex', justifyContent: 'center' }}>{dots}</ul>
      </Box>
    )
  };

  return (
    <Box sx={{ mb: 4, mx: -2, px: 2 }}>
      <Slider ref={sliderRef} {...settings}>
        {trips.map((trip) => (
          <Box key={trip.id} sx={{ px: 0.5 }}>
            <FeaturedTripCard trip={trip} onClick={() => onTripClick(trip.id)} />
          </Box>
        ))}
      </Slider>
    </Box>
  );
}
