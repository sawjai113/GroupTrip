import { Card, CardContent, CardMedia, Typography, Chip, Box, Button } from '@mui/material';
import { Users, Calendar, DollarSign, ArrowRight } from 'lucide-react';

interface FeaturedTripCardProps {
  trip: {
    id: string;
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    participants: string[];
    totalExpenses: number;
    imageUrl: string;
  };
  onClick: () => void;
}

export function FeaturedTripCard({ trip, onClick }: FeaturedTripCardProps) {
  const isUpcoming = new Date(trip.startDate) > new Date();
  const isOngoing = new Date(trip.startDate) <= new Date() && new Date(trip.endDate) >= new Date();

  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        position: 'relative',
        overflow: 'hidden',
        borderRadius: 2
      }}
      onClick={onClick}
    >
      <CardMedia
        component="img"
        height="160"
        image={trip.imageUrl}
        alt={trip.name}
        sx={{ objectFit: 'cover' }}
      />

      {isOngoing && (
        <Chip
          label="NOW"
          color="success"
          size="small"
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            fontWeight: 'bold',
            fontSize: '0.7rem',
            height: 24
          }}
        />
      )}

      {isUpcoming && (
        <Chip
          label="UPCOMING"
          color="primary"
          size="small"
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            fontWeight: 'bold',
            fontSize: '0.7rem',
            height: 24
          }}
        />
      )}

      <CardContent sx={{ p: 2 }}>
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: 0.5 }}>
          {isOngoing ? 'Current Trip' : 'Next Trip'}
        </Typography>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5 }}>
          {trip.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {trip.destination}
        </Typography>

        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1.5, mb: 2 }}>
          <Box sx={{ textAlign: 'center' }}>
            <Calendar size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem' }}>
              {new Date(trip.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Users size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem' }}>
              {trip.participants.length} people
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <DollarSign size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem', fontWeight: 600 }}>
              ${trip.totalExpenses.toFixed(0)}
            </Typography>
          </Box>
        </Box>

        <Button
          variant="contained"
          size="medium"
          endIcon={<ArrowRight size={18} />}
          fullWidth
          onClick={onClick}
          sx={{ py: 1.25 }}
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}
