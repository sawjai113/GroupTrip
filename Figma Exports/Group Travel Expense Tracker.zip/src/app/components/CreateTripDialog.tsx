import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography
} from '@mui/material';

interface CreateTripDialogProps {
  open: boolean;
  onClose: () => void;
  onCreateTrip: (trip: {
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    imageUrl: string;
  }) => void;
}

const DEFAULT_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=800',
    description: 'Mountain adventure'
  },
  {
    url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800',
    description: 'Friends traveling'
  },
  {
    url: 'https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=800',
    description: 'Group celebration'
  },
  {
    url: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800',
    description: 'City skyline'
  },
  {
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800',
    description: 'Beach paradise'
  },
  {
    url: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800',
    description: 'Lake view'
  }
];

export function CreateTripDialog({ open, onClose, onCreateTrip }: CreateTripDialogProps) {
  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [imageUrl, setImageUrl] = useState(DEFAULT_IMAGES[0].url);
  const [customImageUrl, setCustomImageUrl] = useState('');

  const handleSubmit = () => {
    if (name && destination && startDate && endDate) {
      onCreateTrip({
        name,
        destination,
        startDate,
        endDate,
        imageUrl: customImageUrl || imageUrl
      });
      setName('');
      setDestination('');
      setStartDate('');
      setEndDate('');
      setImageUrl(DEFAULT_IMAGES[0].url);
      setCustomImageUrl('');
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>Create New Trip</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <TextField
            label="Trip Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            fullWidth
            required
          />
          <TextField
            label="Destination"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            fullWidth
            required
          />
          <TextField
            label="Start Date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="End Date"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />

          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Cover Image
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2, mb: 2 }}>
              {DEFAULT_IMAGES.map((img) => (
                <Box
                  key={img.url}
                  onClick={() => {
                    setImageUrl(img.url);
                    setCustomImageUrl('');
                  }}
                  sx={{
                    cursor: 'pointer',
                    border: imageUrl === img.url && !customImageUrl ? '3px solid #1976d2' : '2px solid transparent',
                    borderRadius: 1,
                    overflow: 'hidden',
                    transition: 'all 0.2s',
                    '&:hover': {
                      transform: 'scale(1.05)',
                      boxShadow: 2
                    }
                  }}
                >
                  <img
                    src={img.url}
                    alt={img.description}
                    style={{ width: '100%', height: 100, objectFit: 'cover', display: 'block' }}
                  />
                </Box>
              ))}
            </Box>
            <TextField
              label="Or paste custom image URL"
              value={customImageUrl}
              onChange={(e) => setCustomImageUrl(e.target.value)}
              fullWidth
              placeholder="https://example.com/image.jpg"
              size="small"
            />
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Create Trip
        </Button>
      </DialogActions>
    </Dialog>
  );
}
