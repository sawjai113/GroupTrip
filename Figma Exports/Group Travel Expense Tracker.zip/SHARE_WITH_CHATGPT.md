# TravelSplit - Complete Implementation Package
# Copy this entire file and share with ChatGPT or other AI tools

## Project Overview
Mobile-first expense tracking app for group travel, optimized for iOS.

## Technologies
- React 18.3.1 + TypeScript
- Material-UI v7
- react-slick (carousel)
- Lucide React (icons)
- Sonner (toasts)

## Design System

### Colors
- Primary: #1976d2
- Success: #4caf50
- Error: #f44336
- Warning: #ff9800
- Purple: #9c27b0

### Mobile Design Principles
- Touch targets: 44px minimum
- Active states (not hover): scale(0.98)
- Sticky headers with borders
- Border radius: 8-16-24px for cards
- Spacing: 8px base unit (MUI default)

---
## === FILE: package.json ===
```json
{
  "name": "@figma/my-make-file",
  "private": true,
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "build": "vite build"
  },
  "dependencies": {
    "@emotion/react": "11.14.0",
    "@emotion/styled": "11.14.1",
    "@mui/icons-material": "7.3.5",
    "@mui/material": "7.3.5",
    "@popperjs/core": "2.11.8",
    "@radix-ui/react-accordion": "1.2.3",
    "@radix-ui/react-alert-dialog": "1.1.6",
    "@radix-ui/react-aspect-ratio": "1.1.2",
    "@radix-ui/react-avatar": "1.1.3",
    "@radix-ui/react-checkbox": "1.1.4",
    "@radix-ui/react-collapsible": "1.1.3",
    "@radix-ui/react-context-menu": "2.2.6",
    "@radix-ui/react-dialog": "1.1.6",
    "@radix-ui/react-dropdown-menu": "2.1.6",
    "@radix-ui/react-hover-card": "1.1.6",
    "@radix-ui/react-label": "2.1.2",
    "@radix-ui/react-menubar": "1.1.6",
    "@radix-ui/react-navigation-menu": "1.2.5",
    "@radix-ui/react-popover": "1.1.6",
    "@radix-ui/react-progress": "1.1.2",
    "@radix-ui/react-radio-group": "1.2.3",
    "@radix-ui/react-scroll-area": "1.2.3",
    "@radix-ui/react-select": "2.1.6",
    "@radix-ui/react-separator": "1.1.2",
    "@radix-ui/react-slider": "1.2.3",
    "@radix-ui/react-slot": "1.1.2",
    "@radix-ui/react-switch": "1.1.3",
    "@radix-ui/react-tabs": "1.1.3",
    "@radix-ui/react-toggle": "1.1.2",
    "@radix-ui/react-toggle-group": "1.1.2",
    "@radix-ui/react-tooltip": "1.1.8",
    "canvas-confetti": "1.9.4",
    "class-variance-authority": "0.7.1",
    "clsx": "2.1.1",
    "cmdk": "1.1.1",
    "date-fns": "3.6.0",
    "embla-carousel-react": "8.6.0",
    "input-otp": "1.4.2",
    "lucide-react": "0.487.0",
    "motion": "12.23.24",
    "next-themes": "0.4.6",
    "react-day-picker": "8.10.1",
    "react-dnd": "16.0.1",
    "react-dnd-html5-backend": "16.0.1",
    "react-hook-form": "7.55.0",
    "react-popper": "2.3.0",
    "react-resizable-panels": "2.1.7",
    "react-responsive-masonry": "2.7.1",
    "react-router": "7.13.0",
    "react-slick": "0.31.0",
    "recharts": "2.15.2",
    "slick-carousel": "^1.8.1",
    "sonner": "2.0.3",
    "tailwind-merge": "3.2.0",
    "tw-animate-css": "1.3.8",
    "vaul": "1.1.2"
  },
  "devDependencies": {
    "@tailwindcss/vite": "4.1.12",
    "@vitejs/plugin-react": "4.7.0",
    "tailwindcss": "4.1.12",
    "vite": "6.3.5"
  },
  "peerDependencies": {
    "react": "18.3.1",
    "react-dom": "18.3.1"
  },
  "peerDependenciesMeta": {
    "react": {
      "optional": true
    },
    "react-dom": {
      "optional": true
    }
  },
  "pnpm": {
    "overrides": {
      "vite": "6.3.5"
    }
  }
}
```

## === FILE: src/app/App.tsx ===
```typescript
import { useState } from 'react';
import { Box, Typography, Button, Container, Grid, Collapse, IconButton } from '@mui/material';
import { Plus, Plane, ChevronDown, ChevronUp } from 'lucide-react';
import { TripCard } from './components/TripCard';
import { FeaturedTripsCarousel } from './components/FeaturedTripsCarousel';
import { CreateTripDialog } from './components/CreateTripDialog';
import { TripSummary } from './components/TripSummary';
import { TripDetail } from './components/TripDetail';
import { toast, Toaster } from 'sonner';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

const sampleTrips: Trip[] = [
  {
    id: '1',
    name: 'Iceland Adventure',
    destination: 'Reykjavik, Iceland',
    startDate: '2026-05-10',
    endDate: '2026-05-20',
    participants: ['Alice', 'Bob', 'Charlie'],
    totalExpenses: 4250.50,
    imageUrl: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=800'
  },
  {
    id: '2',
    name: 'Tokyo Summer Trip',
    destination: 'Tokyo, Japan',
    startDate: '2026-07-01',
    endDate: '2026-07-14',
    participants: ['David', 'Emma'],
    totalExpenses: 1200.00,
    imageUrl: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800'
  },
  {
    id: '3',
    name: 'Paris Weekend',
    destination: 'Paris, France',
    startDate: '2026-08-20',
    endDate: '2026-08-25',
    participants: ['Alice', 'Frank', 'Grace'],
    totalExpenses: 850.00,
    imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800'
  },
  {
    id: '4',
    name: 'Barcelona Getaway',
    destination: 'Barcelona, Spain',
    startDate: '2026-03-10',
    endDate: '2026-03-17',
    participants: ['David', 'Emma'],
    totalExpenses: 2450.00,
    imageUrl: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800'
  },
  {
    id: '5',
    name: 'Thailand Beach Trip',
    destination: 'Phuket, Thailand',
    startDate: '2025-12-20',
    endDate: '2026-01-05',
    participants: ['Alice', 'Frank', 'Grace'],
    totalExpenses: 3890.75,
    imageUrl: 'https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=800'
  }
];

const sampleExpenses: Record<string, Expense[]> = {
  '1': [
    {
      id: 'e1',
      description: 'Hotel booking',
      amount: 1200.00,
      paidBy: 'Alice',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Accommodation',
      date: '2026-06-15'
    },
    {
      id: 'e2',
      description: 'Sushi dinner',
      amount: 180.50,
      paidBy: 'Bob',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Food',
      date: '2026-06-16'
    },
    {
      id: 'e3',
      description: 'Train tickets to Kyoto',
      amount: 270.00,
      paidBy: 'Charlie',
      splitAmong: ['Alice', 'Bob', 'Charlie'],
      category: 'Transportation',
      date: '2026-06-18'
    }
  ],
  '2': [
    {
      id: 'e4',
      description: 'Airbnb',
      amount: 1500.00,
      paidBy: 'David',
      splitAmong: ['David', 'Emma'],
      category: 'Accommodation',
      date: '2026-07-01'
    }
  ]
};

type ViewMode = 'list' | 'summary' | 'expenses';

export default function App() {
  const [trips, setTrips] = useState<Trip[]>(sampleTrips);
  const [expenses, setExpenses] = useState<Record<string, Expense[]>>(sampleExpenses);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedTripId, setSelectedTripId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [pastTripsOpen, setPastTripsOpen] = useState(false);

  const selectedTrip = trips.find(t => t.id === selectedTripId);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sortedTrips = [...trips].sort((a, b) =>
    new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
  );

  const currentTrip = sortedTrips.find(trip =>
    new Date(trip.startDate) <= today && new Date(trip.endDate) >= today
  );

  const allFutureTrips = sortedTrips.filter(trip => new Date(trip.startDate) > today);

  const featuredTrips = currentTrip ? [currentTrip, ...allFutureTrips] : allFutureTrips;

  const pastTrips = sortedTrips.filter(trip => new Date(trip.endDate) < today).reverse();

  const handleCreateTrip = (tripData: {
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    imageUrl: string;
  }) => {
    const newTrip: Trip = {
      id: Date.now().toString(),
      ...tripData,
      participants: [],
      totalExpenses: 0
    };
    setTrips([...trips, newTrip]);
    setExpenses({ ...expenses, [newTrip.id]: [] });
  };

  const handleAddExpense = (tripId: string, expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      id: Date.now().toString(),
      ...expenseData
    };

    const tripExpenses = [...(expenses[tripId] || []), newExpense];
    setExpenses({ ...expenses, [tripId]: tripExpenses });

    const totalExpenses = tripExpenses.reduce((sum, e) => sum + e.amount, 0);
    setTrips(trips.map(t =>
      t.id === tripId ? { ...t, totalExpenses } : t
    ));
  };

  const handleDeleteExpense = (tripId: string, expenseId: string) => {
    const tripExpenses = expenses[tripId].filter(e => e.id !== expenseId);
    setExpenses({ ...expenses, [tripId]: tripExpenses });

    const totalExpenses = tripExpenses.reduce((sum, e) => sum + e.amount, 0);
    setTrips(trips.map(t =>
      t.id === tripId ? { ...t, totalExpenses } : t
    ));
  };

  const handleAddParticipant = (tripId: string, name: string) => {
    setTrips(trips.map(t =>
      t.id === tripId
        ? { ...t, participants: [...t.participants, name] }
        : t
    ));
  };

  const handleTripClick = (tripId: string) => {
    setSelectedTripId(tripId);
    setViewMode('summary');
  };

  const handleBackToList = () => {
    setSelectedTripId(null);
    setViewMode('list');
  };

  const handleBackToSummary = () => {
    setViewMode('summary');
  };

  const handleFeatureNotReady = (featureName: string) => {
    toast.info(`${featureName} coming soon!`);
  };

  if (selectedTrip && viewMode === 'summary') {
    return (
      <TripSummary
        trip={selectedTrip}
        onBack={handleBackToList}
        onOpenExpenses={() => setViewMode('expenses')}
        onInviteParticipants={() => handleFeatureNotReady('Invite Participants')}
        onOpenChat={() => handleFeatureNotReady('Trip Chat')}
        onOpenInterests={() => handleFeatureNotReady('Places & Interests')}
        onOpenCalendar={() => handleFeatureNotReady('Itinerary')}
        onOpenMap={() => handleFeatureNotReady('Map View')}
      />
    );
  }

  if (selectedTrip && viewMode === 'expenses') {
    return (
      <TripDetail
        trip={selectedTrip}
        expenses={expenses[selectedTrip.id] || []}
        onBack={handleBackToSummary}
        onAddExpense={(expense) => handleAddExpense(selectedTrip.id, expense)}
        onAddParticipant={(name) => handleAddParticipant(selectedTrip.id, name)}
        onDeleteExpense={(expenseId) => handleDeleteExpense(selectedTrip.id, expenseId)}
      />
    );
  }

  return (
    <>
      <Toaster position="top-center" />
      <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', pb: 2 }}>
        <Box sx={{
          position: 'sticky',
          top: 0,
          bgcolor: 'background.paper',
          zIndex: 10,
          borderBottom: '1px solid',
          borderColor: 'divider',
          px: 2,
          py: 2
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Plane size={28} color="#1976d2" />
              <Typography variant="h5">TravelSplit</Typography>
            </Box>
            <Button
              variant="contained"
              size="small"
              startIcon={<Plus size={18} />}
              onClick={() => setCreateDialogOpen(true)}
            >
              New
            </Button>
          </Box>
          <Typography variant="body2" color="text.secondary">
            Track expenses with friends
          </Typography>
        </Box>

        <Box sx={{ px: 2, pt: 2 }}>

        {trips.length === 0 ? (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Plane size={64} color="#ccc" style={{ marginBottom: 16 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No trips yet
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Create your first trip to start tracking expenses
            </Typography>
            <Button
              variant="contained"
              startIcon={<Plus size={20} />}
              onClick={() => setCreateDialogOpen(true)}
            >
              Create Your First Trip
            </Button>
          </Box>
        ) : (
          <Box>
            {featuredTrips.length > 0 && (
              <FeaturedTripsCarousel
                trips={featuredTrips}
                onTripClick={handleTripClick}
              />
            )}

            {pastTrips.length > 0 && (
              <Box>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    mb: 2,
                    cursor: 'pointer',
                    py: 1,
                    '&:active': { opacity: 0.7 }
                  }}
                  onClick={() => setPastTripsOpen(!pastTripsOpen)}
                >
                  <Typography variant="h6">Past Trips</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Typography variant="body2" color="text.secondary">{pastTrips.length}</Typography>
                    <IconButton size="small">
                      {pastTripsOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </IconButton>
                  </Box>
                </Box>

                <Collapse in={pastTripsOpen}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    {pastTrips.map(trip => (
                      <TripCard key={trip.id} trip={trip} onClick={() => handleTripClick(trip.id)} />
                    ))}
                  </Box>
                </Collapse>
              </Box>
            )}

            {featuredTrips.length === 0 && pastTrips.length === 0 && (
              <Box sx={{ textAlign: 'center', py: 8 }}>
                <Typography variant="body1" color="text.secondary">
                  All your trips are in the past. Create a new one!
                </Typography>
              </Box>
            )}
          </Box>
        )}

        <CreateTripDialog
          open={createDialogOpen}
          onClose={() => setCreateDialogOpen(false)}
          onCreateTrip={handleCreateTrip}
        />
        </Box>
      </Box>
    </>
  );
}```

## === FILE: src/app/components/TripSummary.tsx ===
```typescript
import { Box, Typography, IconButton, Avatar, AvatarGroup, Card, CardContent, CardMedia } from '@mui/material';
import {
  ArrowLeft,
  UserPlus,
  MessageCircle,
  MapPin,
  Calendar as CalendarIcon,
  Map,
  Receipt,
  ChevronRight
} from 'lucide-react';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface TripSummaryProps {
  trip: Trip;
  onBack: () => void;
  onOpenExpenses: () => void;
  onInviteParticipants: () => void;
  onOpenChat: () => void;
  onOpenInterests: () => void;
  onOpenCalendar: () => void;
  onOpenMap: () => void;
}

interface ActionCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  color?: string;
}

function ActionCard({ icon, title, description, onClick, color = '#1976d2' }: ActionCardProps) {
  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        borderRadius: 2
      }}
      onClick={onClick}
    >
      <CardContent sx={{ p: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              bgcolor: `${color}15`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}
          >
            {icon}
          </Box>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="body1" sx={{ fontWeight: 600 }} gutterBottom>
              {title}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.85rem' }}>
              {description}
            </Typography>
          </Box>
          <ChevronRight size={20} color="#999" />
        </Box>
      </CardContent>
    </Card>
  );
}

export function TripSummary({
  trip,
  onBack,
  onOpenExpenses,
  onInviteParticipants,
  onOpenChat,
  onOpenInterests,
  onOpenCalendar,
  onOpenMap
}: TripSummaryProps) {
  const startDate = new Date(trip.startDate);
  const endDate = new Date(trip.endDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isUpcoming = startDate > today;
  const isOngoing = startDate <= today && endDate >= today;

  const formatDateRange = () => {
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric', year: 'numeric' };
    return `${startDate.toLocaleDateString('en-US', options)} - ${endDate.toLocaleDateString('en-US', options)}`;
  };

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default' }}>
      <Box sx={{ position: 'relative' }}>
        <CardMedia
          component="img"
          height="220"
          image={trip.imageUrl}
          alt={trip.name}
          sx={{ objectFit: 'cover' }}
        />
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            background: 'linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0) 100%)',
            p: 2
          }}
        >
          <IconButton
            onClick={onBack}
            sx={{
              bgcolor: 'rgba(255,255,255,0.9)',
              '&:hover': { bgcolor: 'white' }
            }}
          >
            <ArrowLeft size={24} />
          </IconButton>
        </Box>
      </Box>

      <Box sx={{ px: 2, pt: 2, pb: 3 }}>
        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 600, mb: 0.5 }}>
                {trip.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {trip.destination}
              </Typography>
            </Box>
            {(isOngoing || isUpcoming) && (
              <Box
                sx={{
                  bgcolor: isOngoing ? '#4caf50' : '#1976d2',
                  color: 'white',
                  px: 1.5,
                  py: 0.5,
                  borderRadius: 1,
                  fontSize: '0.75rem',
                  fontWeight: 600
                }}
              >
                {isOngoing ? 'NOW' : 'UPCOMING'}
              </Box>
            )}
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {formatDateRange()}
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <AvatarGroup max={5} sx={{ '& .MuiAvatar-root': { width: 32, height: 32, fontSize: '0.875rem' } }}>
              {trip.participants.map((participant, index) => (
                <Avatar key={participant} sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)` }}>
                  {participant[0].toUpperCase()}
                </Avatar>
              ))}
            </AvatarGroup>
            <Typography variant="body2" color="text.secondary">
              {trip.participants.length} {trip.participants.length === 1 ? 'traveler' : 'travelers'}
            </Typography>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <ActionCard
            icon={<Receipt size={24} color="#1976d2" />}
            title="Expenses"
            description={`Track and split costs • $${trip.totalExpenses.toFixed(2)} total`}
            onClick={onOpenExpenses}
            color="#1976d2"
          />

          <ActionCard
            icon={<UserPlus size={24} color="#9c27b0" />}
            title="Invite Participants"
            description="Add friends to your trip"
            onClick={onInviteParticipants}
            color="#9c27b0"
          />

          <ActionCard
            icon={<MessageCircle size={24} color="#2196f3" />}
            title="Trip Chat"
            description="Discuss plans with your group"
            onClick={onOpenChat}
            color="#2196f3"
          />

          <ActionCard
            icon={<MapPin size={24} color="#f44336" />}
            title="Places & Interests"
            description="Save restaurants, shops, and attractions"
            onClick={onOpenInterests}
            color="#f44336"
          />

          <ActionCard
            icon={<CalendarIcon size={24} color="#ff9800" />}
            title="Itinerary"
            description="Plan your daily schedule"
            onClick={onOpenCalendar}
            color="#ff9800"
          />

          <ActionCard
            icon={<Map size={24} color="#4caf50" />}
            title="Map View"
            description="See all your saved places on a map"
            onClick={onOpenMap}
            color="#4caf50"
          />
        </Box>
      </Box>
    </Box>
  );
}
```

## === FILE: src/app/components/FeaturedTripsCarousel.tsx ===
```typescript
import { useRef } from 'react';
import { Box } from '@mui/material';
import Slider from 'react-slick';
import { FeaturedTripCard } from './FeaturedTripCard';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface FeaturedTripsCarouselProps {
  trips: Trip[];
  onTripClick: (tripId: string) => void;
}

export function FeaturedTripsCarousel({ trips, onTripClick }: FeaturedTripsCarouselProps) {
  const sliderRef = useRef<Slider>(null);

  if (trips.length === 0) return null;

  const settings = {
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    swipeToSlide: true,
    touchThreshold: 10,
    customPaging: () => (
      <div
        style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          backgroundColor: '#ccc',
          margin: '0 4px'
        }}
      />
    ),
    dotsClass: 'slick-dots custom-dots',
    appendDots: (dots: React.ReactNode) => (
      <Box
        sx={{
          position: 'relative',
          bottom: '-16px',
          '& li': {
            margin: '0 2px'
          },
          '& li.slick-active div': {
            backgroundColor: '#1976d2',
            width: '24px',
            borderRadius: '4px'
          }
        }}
      >
        <ul style={{ margin: 0, padding: 0, display: 'flex', justifyContent: 'center' }}>{dots}</ul>
      </Box>
    )
  };

  return (
    <Box sx={{ mb: 4, mx: -2, px: 2 }}>
      <Slider ref={sliderRef} {...settings}>
        {trips.map((trip) => (
          <Box key={trip.id} sx={{ px: 0.5 }}>
            <FeaturedTripCard trip={trip} onClick={() => onTripClick(trip.id)} />
          </Box>
        ))}
      </Slider>
    </Box>
  );
}
```

## === FILE: src/app/components/FeaturedTripCard.tsx ===
```typescript
import { Card, CardContent, CardMedia, Typography, Chip, Box, Button } from '@mui/material';
import { Users, Calendar, DollarSign, ArrowRight } from 'lucide-react';

interface FeaturedTripCardProps {
  trip: {
    id: string;
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    participants: string[];
    totalExpenses: number;
    imageUrl: string;
  };
  onClick: () => void;
}

export function FeaturedTripCard({ trip, onClick }: FeaturedTripCardProps) {
  const isUpcoming = new Date(trip.startDate) > new Date();
  const isOngoing = new Date(trip.startDate) <= new Date() && new Date(trip.endDate) >= new Date();

  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        position: 'relative',
        overflow: 'hidden',
        borderRadius: 2
      }}
      onClick={onClick}
    >
      <CardMedia
        component="img"
        height="160"
        image={trip.imageUrl}
        alt={trip.name}
        sx={{ objectFit: 'cover' }}
      />

      {isOngoing && (
        <Chip
          label="NOW"
          color="success"
          size="small"
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            fontWeight: 'bold',
            fontSize: '0.7rem',
            height: 24
          }}
        />
      )}

      {isUpcoming && (
        <Chip
          label="UPCOMING"
          color="primary"
          size="small"
          sx={{
            position: 'absolute',
            top: 8,
            right: 8,
            fontWeight: 'bold',
            fontSize: '0.7rem',
            height: 24
          }}
        />
      )}

      <CardContent sx={{ p: 2 }}>
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: 0.5 }}>
          {isOngoing ? 'Current Trip' : 'Next Trip'}
        </Typography>
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 0.5 }}>
          {trip.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {trip.destination}
        </Typography>

        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1.5, mb: 2 }}>
          <Box sx={{ textAlign: 'center' }}>
            <Calendar size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem' }}>
              {new Date(trip.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <Users size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem' }}>
              {trip.participants.length} people
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'center' }}>
            <DollarSign size={16} color="#1976d2" style={{ marginBottom: 4 }} />
            <Typography variant="caption" color="text.secondary" display="block" sx={{ fontSize: '0.65rem', fontWeight: 600 }}>
              ${trip.totalExpenses.toFixed(0)}
            </Typography>
          </Box>
        </Box>

        <Button
          variant="contained"
          size="medium"
          endIcon={<ArrowRight size={18} />}
          fullWidth
          onClick={onClick}
          sx={{ py: 1.25 }}
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}
```

## === FILE: src/app/components/TripCard.tsx ===
```typescript
import { Card, CardContent, CardMedia, Typography, Chip, Box } from '@mui/material';
import { Users, Calendar, DollarSign } from 'lucide-react';

interface TripCardProps {
  trip: {
    id: string;
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    participants: string[];
    totalExpenses: number;
    imageUrl: string;
  };
  onClick: () => void;
}

export function TripCard({ trip, onClick }: TripCardProps) {
  return (
    <Card
      sx={{
        cursor: 'pointer',
        transition: 'transform 0.15s',
        '&:active': {
          transform: 'scale(0.98)'
        },
        borderRadius: 2,
        display: 'flex',
        overflow: 'hidden'
      }}
      onClick={onClick}
    >
      <CardMedia
        component="img"
        sx={{ width: 120, height: 120, flexShrink: 0 }}
        image={trip.imageUrl}
        alt={trip.name}
      />
      <CardContent sx={{ flex: 1, p: 2 }}>
        <Typography variant="body1" sx={{ fontWeight: 600 }} gutterBottom>
          {trip.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" gutterBottom>
          {trip.destination}
        </Typography>

        <Box sx={{ display: 'flex', gap: 1, mt: 1.5, flexWrap: 'wrap' }}>
          <Chip
            icon={<Calendar size={14} />}
            label={new Date(trip.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
            size="small"
            variant="outlined"
          />
          <Chip
            icon={<Users size={14} />}
            label={trip.participants.length}
            size="small"
            variant="outlined"
          />
          <Chip
            icon={<DollarSign size={14} />}
            label={`$${trip.totalExpenses.toFixed(0)}`}
            size="small"
            color="primary"
            variant="outlined"
          />
        </Box>
      </CardContent>
    </Card>
  );
}
```

## === FILE: src/app/components/TripDetail.tsx ===
```typescript
import { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Tabs,
  Tab,
  Card,
  CardContent,
  IconButton,
  Chip,
  Avatar,
  AvatarGroup
} from '@mui/material';
import { ArrowLeft, Plus, Users, Receipt, TrendingUp } from 'lucide-react';
import { AddExpenseDialog } from './AddExpenseDialog';
import { AddParticipantDialog } from './AddParticipantDialog';
import { ExpenseList } from './ExpenseList';
import { BalancesSummary } from './BalancesSummary';

interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: string[];
  totalExpenses: number;
  imageUrl: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface TripDetailProps {
  trip: Trip;
  expenses: Expense[];
  onBack: () => void;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onAddParticipant: (name: string) => void;
  onDeleteExpense: (id: string) => void;
}

export function TripDetail({
  trip,
  expenses,
  onBack,
  onAddExpense,
  onAddParticipant,
  onDeleteExpense
}: TripDetailProps) {
  const [currentTab, setCurrentTab] = useState(0);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);
  const [participantDialogOpen, setParticipantDialogOpen] = useState(false);

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'background.default', pb: 2 }}>
      <Box sx={{
        position: 'sticky',
        top: 0,
        bgcolor: 'background.paper',
        zIndex: 10,
        borderBottom: '1px solid',
        borderColor: 'divider',
        px: 2,
        py: 1.5
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
          <IconButton onClick={onBack} size="small">
            <ArrowLeft size={24} />
          </IconButton>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="h6" noWrap>{trip.name}</Typography>
            <Typography variant="caption" color="text.secondary" noWrap>
              {trip.destination}
            </Typography>
          </Box>
          <AvatarGroup max={3} sx={{ '& .MuiAvatar-root': { width: 32, height: 32, fontSize: '0.875rem' } }}>
            {trip.participants.map((participant, index) => (
              <Avatar key={participant} sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)` }}>
                {participant[0].toUpperCase()}
              </Avatar>
            ))}
          </AvatarGroup>
        </Box>
      </Box>

      <Box sx={{ px: 2, pt: 2 }}>

      <Card sx={{ mb: 2, borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <Receipt size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">Total</Typography>
              <Typography variant="h6">${trip.totalExpenses.toFixed(0)}</Typography>
            </Box>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <Users size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">People</Typography>
              <Typography variant="h6">{trip.participants.length}</Typography>
            </Box>
            <Box sx={{ textAlign: 'center' }}>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 0.5 }}>
                <TrendingUp size={18} color="#1976d2" />
              </Box>
              <Typography variant="caption" color="text.secondary" display="block">Per Person</Typography>
              <Typography variant="h6">
                ${trip.participants.length > 0 ? (trip.totalExpenses / trip.participants.length).toFixed(0) : '0'}
              </Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs
          value={currentTab}
          onChange={(_, newValue) => setCurrentTab(newValue)}
          variant="fullWidth"
          sx={{ minHeight: 48 }}
        >
          <Tab label="Expenses" sx={{ minHeight: 48, py: 1 }} />
          <Tab label="Balances" sx={{ minHeight: 48, py: 1 }} />
          <Tab label="People" sx={{ minHeight: 48, py: 1 }} />
        </Tabs>
      </Box>

      {currentTab === 0 && (
        <Box>
          <Box sx={{ mb: 2 }}>
            <Button
              variant="contained"
              startIcon={<Plus size={18} />}
              onClick={() => setExpenseDialogOpen(true)}
              fullWidth
              sx={{ py: 1.5 }}
            >
              Add Expense
            </Button>
          </Box>
          <ExpenseList expenses={expenses} participants={trip.participants} onDelete={onDeleteExpense} />
        </Box>
      )}

      {currentTab === 1 && (
        <BalancesSummary expenses={expenses} participants={trip.participants} />
      )}

      {currentTab === 2 && (
        <Box>
          <Box sx={{ mb: 2 }}>
            <Button
              variant="contained"
              startIcon={<Plus size={18} />}
              onClick={() => setParticipantDialogOpen(true)}
              fullWidth
              sx={{ py: 1.5 }}
            >
              Add Participant
            </Button>
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {trip.participants.map((participant, index) => (
              <Card key={participant} sx={{ borderRadius: 2 }}>
                <CardContent sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Avatar sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)`, width: 48, height: 48 }}>
                      {participant[0].toUpperCase()}
                    </Avatar>
                    <Box>
                      <Typography variant="body1" sx={{ fontWeight: 600 }}>{participant}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {expenses.filter(e => e.paidBy === participant).length} expenses paid
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </Box>
        </Box>
      )}

      <AddExpenseDialog
        open={expenseDialogOpen}
        onClose={() => setExpenseDialogOpen(false)}
        participants={trip.participants}
        onAddExpense={onAddExpense}
      />

      <AddParticipantDialog
        open={participantDialogOpen}
        onClose={() => setParticipantDialogOpen(false)}
        onAddParticipant={onAddParticipant}
      />
      </Box>
    </Box>
  );
}
```

## === FILE: src/app/components/ExpenseList.tsx ===
```typescript
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  IconButton,
  Avatar,
  Divider
} from '@mui/material';
import { Trash2, Users } from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface ExpenseListProps {
  expenses: Expense[];
  participants: string[];
  onDelete: (id: string) => void;
}

const categoryColors: Record<string, string> = {
  Food: '#FF6B6B',
  Accommodation: '#4ECDC4',
  Transportation: '#45B7D1',
  Activities: '#FFA07A',
  Shopping: '#98D8C8',
  Other: '#95A5A6'
};

export function ExpenseList({ expenses, participants, onDelete }: ExpenseListProps) {
  if (expenses.length === 0) {
    return (
      <Card>
        <CardContent>
          <Typography variant="body1" color="text.secondary" textAlign="center" py={4}>
            No expenses yet. Add your first expense to get started!
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const sortedExpenses = [...expenses].sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
      {sortedExpenses.map((expense) => {
        const participantIndex = participants.indexOf(expense.paidBy);
        const avatarColor = `hsl(${participantIndex * 60}, 70%, 50%)`;

        return (
          <Card key={expense.id} sx={{ borderRadius: 2 }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                <Avatar sx={{ bgcolor: avatarColor, width: 40, height: 40 }}>
                  {expense.paidBy[0].toUpperCase()}
                </Avatar>

                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 0.5 }}>
                    <Box sx={{ flex: 1, minWidth: 0, mr: 1 }}>
                      <Typography variant="body1" sx={{ fontWeight: 600 }} noWrap>
                        {expense.description}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        {expense.paidBy} • {new Date(expense.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexShrink: 0 }}>
                      <Typography variant="body1" color="primary" sx={{ fontWeight: 600 }}>
                        ${expense.amount.toFixed(2)}
                      </Typography>
                      <IconButton size="small" onClick={() => onDelete(expense.id)} color="error">
                        <Trash2 size={16} />
                      </IconButton>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 1 }}>
                    <Chip
                      label={expense.category}
                      size="small"
                      sx={{
                        bgcolor: categoryColors[expense.category],
                        color: 'white',
                        height: 24,
                        fontSize: '0.7rem'
                      }}
                    />
                    <Chip
                      icon={<Users size={12} />}
                      label={`${expense.splitAmong.length} people`}
                      size="small"
                      variant="outlined"
                      sx={{ height: 24, fontSize: '0.7rem' }}
                    />
                    <Chip
                      label={`$${(expense.amount / expense.splitAmong.length).toFixed(2)} each`}
                      size="small"
                      variant="outlined"
                      sx={{ height: 24, fontSize: '0.7rem' }}
                    />
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        );
      })}
    </Box>
  );
}
```

## === FILE: src/app/components/BalancesSummary.tsx ===
```typescript
import { Card, CardContent, Typography, Box, Avatar, Divider, Chip } from '@mui/material';
import { ArrowRight, CheckCircle } from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  category: string;
  date: string;
}

interface BalancesSummaryProps {
  expenses: Expense[];
  participants: string[];
}

interface Balance {
  person: string;
  balance: number;
}

interface Settlement {
  from: string;
  to: string;
  amount: number;
}

function calculateBalances(expenses: Expense[], participants: string[]): Balance[] {
  const balances: Record<string, number> = {};

  participants.forEach(p => {
    balances[p] = 0;
  });

  expenses.forEach(expense => {
    const sharePerPerson = expense.amount / expense.splitAmong.length;

    balances[expense.paidBy] += expense.amount;

    expense.splitAmong.forEach(person => {
      balances[person] -= sharePerPerson;
    });
  });

  return Object.entries(balances).map(([person, balance]) => ({
    person,
    balance
  }));
}

function calculateSettlements(balances: Balance[]): Settlement[] {
  const settlements: Settlement[] = [];
  const debts = balances.filter(b => b.balance < -0.01).map(b => ({ ...b }));
  const credits = balances.filter(b => b.balance > 0.01).map(b => ({ ...b }));

  let debtIndex = 0;
  let creditIndex = 0;

  while (debtIndex < debts.length && creditIndex < credits.length) {
    const debt = debts[debtIndex];
    const credit = credits[creditIndex];
    const amount = Math.min(-debt.balance, credit.balance);

    if (amount > 0.01) {
      settlements.push({
        from: debt.person,
        to: credit.person,
        amount
      });
    }

    debt.balance += amount;
    credit.balance -= amount;

    if (Math.abs(debt.balance) < 0.01) debtIndex++;
    if (Math.abs(credit.balance) < 0.01) creditIndex++;
  }

  return settlements;
}

export function BalancesSummary({ expenses, participants }: BalancesSummaryProps) {
  const balances = calculateBalances(expenses, participants);
  const settlements = calculateSettlements(balances);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Card sx={{ borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="body1" sx={{ fontWeight: 600, mb: 1.5 }}>
            Individual Balances
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {balances.map((balance, index) => (
              <Box key={balance.person} sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Avatar sx={{ bgcolor: `hsl(${index * 60}, 70%, 50%)`, width: 36, height: 36 }}>
                  {balance.person[0].toUpperCase()}
                </Avatar>
                <Typography variant="body2" sx={{ flex: 1 }}>
                  {balance.person}
                </Typography>
                <Chip
                  label={`${balance.balance >= 0 ? '+' : ''}$${balance.balance.toFixed(2)}`}
                  color={balance.balance > 0.01 ? 'success' : balance.balance < -0.01 ? 'error' : 'default'}
                  size="small"
                  sx={{ minWidth: 90, fontWeight: 600 }}
                />
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>

      <Card sx={{ borderRadius: 2 }}>
        <CardContent sx={{ p: 2 }}>
          <Typography variant="body1" sx={{ fontWeight: 600, mb: 1.5 }}>
            Suggested Settlements
          </Typography>
          {settlements.length === 0 ? (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <CheckCircle size={40} color="#4caf50" style={{ marginBottom: 12 }} />
              <Typography variant="body2" color="text.secondary">
                All settled up!
              </Typography>
            </Box>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              {settlements.map((settlement, index) => {
                const fromIndex = participants.indexOf(settlement.from);
                const toIndex = participants.indexOf(settlement.to);

                return (
                  <Card key={index} variant="outlined" sx={{ bgcolor: 'action.hover', borderRadius: 1.5 }}>
                    <CardContent sx={{ p: 1.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Avatar sx={{ bgcolor: `hsl(${fromIndex * 60}, 70%, 50%)`, width: 32, height: 32, fontSize: '0.875rem' }}>
                          {settlement.from[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2" sx={{ minWidth: 0, flex: '0 0 auto' }}>{settlement.from}</Typography>
                        <ArrowRight size={18} style={{ flexShrink: 0 }} />
                        <Avatar sx={{ bgcolor: `hsl(${toIndex * 60}, 70%, 50%)`, width: 32, height: 32, fontSize: '0.875rem' }}>
                          {settlement.to[0].toUpperCase()}
                        </Avatar>
                        <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }}>{settlement.to}</Typography>
                        <Chip
                          label={`$${settlement.amount.toFixed(2)}`}
                          color="primary"
                          size="small"
                          sx={{ minWidth: 75, fontWeight: 600 }}
                        />
                      </Box>
                    </CardContent>
                  </Card>
                );
              })}
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
```

## === FILE: src/app/components/CreateTripDialog.tsx ===
```typescript
import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography
} from '@mui/material';

interface CreateTripDialogProps {
  open: boolean;
  onClose: () => void;
  onCreateTrip: (trip: {
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    imageUrl: string;
  }) => void;
}

const DEFAULT_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1506869640319-fe1a24fd76dc?w=800',
    description: 'Mountain adventure'
  },
  {
    url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800',
    description: 'Friends traveling'
  },
  {
    url: 'https://images.unsplash.com/photo-1539635278303-d4002c07eae3?w=800',
    description: 'Group celebration'
  },
  {
    url: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800',
    description: 'City skyline'
  },
  {
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800',
    description: 'Beach paradise'
  },
  {
    url: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800',
    description: 'Lake view'
  }
];

export function CreateTripDialog({ open, onClose, onCreateTrip }: CreateTripDialogProps) {
  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [imageUrl, setImageUrl] = useState(DEFAULT_IMAGES[0].url);
  const [customImageUrl, setCustomImageUrl] = useState('');

  const handleSubmit = () => {
    if (name && destination && startDate && endDate) {
      onCreateTrip({
        name,
        destination,
        startDate,
        endDate,
        imageUrl: customImageUrl || imageUrl
      });
      setName('');
      setDestination('');
      setStartDate('');
      setEndDate('');
      setImageUrl(DEFAULT_IMAGES[0].url);
      setCustomImageUrl('');
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>Create New Trip</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <TextField
            label="Trip Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            fullWidth
            required
          />
          <TextField
            label="Destination"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            fullWidth
            required
          />
          <TextField
            label="Start Date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="End Date"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />

          <Box sx={{ mt: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Cover Image
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2, mb: 2 }}>
              {DEFAULT_IMAGES.map((img) => (
                <Box
                  key={img.url}
                  onClick={() => {
                    setImageUrl(img.url);
                    setCustomImageUrl('');
                  }}
                  sx={{
                    cursor: 'pointer',
                    border: imageUrl === img.url && !customImageUrl ? '3px solid #1976d2' : '2px solid transparent',
                    borderRadius: 1,
                    overflow: 'hidden',
                    transition: 'all 0.2s',
                    '&:hover': {
                      transform: 'scale(1.05)',
                      boxShadow: 2
                    }
                  }}
                >
                  <img
                    src={img.url}
                    alt={img.description}
                    style={{ width: '100%', height: 100, objectFit: 'cover', display: 'block' }}
                  />
                </Box>
              ))}
            </Box>
            <TextField
              label="Or paste custom image URL"
              value={customImageUrl}
              onChange={(e) => setCustomImageUrl(e.target.value)}
              fullWidth
              placeholder="https://example.com/image.jpg"
              size="small"
            />
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Create Trip
        </Button>
      </DialogActions>
    </Dialog>
  );
}
```

## === FILE: src/app/components/AddExpenseDialog.tsx ===
```typescript
import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  FormGroup,
  InputAdornment
} from '@mui/material';

interface AddExpenseDialogProps {
  open: boolean;
  onClose: () => void;
  participants: string[];
  onAddExpense: (expense: {
    description: string;
    amount: number;
    paidBy: string;
    splitAmong: string[];
    category: string;
    date: string;
  }) => void;
}

const categories = ['Food', 'Accommodation', 'Transportation', 'Activities', 'Shopping', 'Other'];

export function AddExpenseDialog({ open, onClose, participants, onAddExpense }: AddExpenseDialogProps) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paidBy, setPaidBy] = useState('');
  const [splitAmong, setSplitAmong] = useState<string[]>(participants);
  const [category, setCategory] = useState('Food');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleSubmit = () => {
    if (description && amount && paidBy && splitAmong.length > 0) {
      onAddExpense({
        description,
        amount: parseFloat(amount),
        paidBy,
        splitAmong,
        category,
        date
      });
      setDescription('');
      setAmount('');
      setPaidBy('');
      setSplitAmong(participants);
      setCategory('Food');
      setDate(new Date().toISOString().split('T')[0]);
      onClose();
    }
  };

  const handleToggleParticipant = (participant: string) => {
    if (splitAmong.includes(participant)) {
      setSplitAmong(splitAmong.filter(p => p !== participant));
    } else {
      setSplitAmong([...splitAmong, participant]);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Add Expense</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <TextField
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            fullWidth
            required
            placeholder="e.g., Dinner at restaurant"
          />

          <TextField
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            fullWidth
            required
            InputProps={{
              startAdornment: <InputAdornment position="start">$</InputAdornment>
            }}
          />

          <FormControl fullWidth required>
            <InputLabel>Category</InputLabel>
            <Select value={category} onChange={(e) => setCategory(e.target.value)} label="Category">
              {categories.map(cat => (
                <MenuItem key={cat} value={cat}>{cat}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            label="Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            fullWidth
            required
            InputLabelProps={{ shrink: true }}
          />

          <FormControl fullWidth required>
            <InputLabel>Paid By</InputLabel>
            <Select value={paidBy} onChange={(e) => setPaidBy(e.target.value)} label="Paid By">
              {participants.map(participant => (
                <MenuItem key={participant} value={participant}>{participant}</MenuItem>
              ))}
            </Select>
          </FormControl>

          <Box>
            <InputLabel sx={{ mb: 1 }}>Split Among</InputLabel>
            <FormGroup>
              {participants.map(participant => (
                <FormControlLabel
                  key={participant}
                  control={
                    <Checkbox
                      checked={splitAmong.includes(participant)}
                      onChange={() => handleToggleParticipant(participant)}
                    />
                  }
                  label={participant}
                />
              ))}
            </FormGroup>
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Add Expense
        </Button>
      </DialogActions>
    </Dialog>
  );
}
```

## === FILE: src/app/components/AddParticipantDialog.tsx ===
```typescript
import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box
} from '@mui/material';

interface AddParticipantDialogProps {
  open: boolean;
  onClose: () => void;
  onAddParticipant: (name: string) => void;
}

export function AddParticipantDialog({ open, onClose, onAddParticipant }: AddParticipantDialogProps) {
  const [name, setName] = useState('');

  const handleSubmit = () => {
    if (name.trim()) {
      onAddParticipant(name.trim());
      setName('');
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Add Participant</DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <TextField
            label="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            fullWidth
            required
            autoFocus
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSubmit();
              }
            }}
          />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Add
        </Button>
      </DialogActions>
    </Dialog>
  );
}
```

---
## Implementation Complete
All files above preserve the exact mobile design with proper spacing, colors, and interactions.
