# TravelSplit - Implementation Guide

## Project Structure
```
src/
├── app/
│   ├── App.tsx                          # Main app with navigation logic
│   └── components/
│       ├── FeaturedTripsCarousel.tsx    # Swipeable trip carousel
│       ├── TripCard.tsx                 # Compact trip card (past trips)
│       ├── FeaturedTripCard.tsx         # Large featured card
│       ├── TripSummary.tsx              # Middle layer with action cards
│       ├── TripDetail.tsx               # Expense tracking page
│       ├── ExpenseList.tsx              # List of expenses
│       ├── BalancesSummary.tsx          # Balance calculations
│       ├── AddExpenseDialog.tsx         # Add expense modal
│       ├── AddParticipantDialog.tsx     # Add participant modal
│       └── CreateTripDialog.tsx         # Create trip modal
```

## Key Technologies
- React 18.3.1
- Material-UI (MUI) v7
- react-slick (carousel)
- Lucide React (icons)
- Sonner (toasts)

## Implementation Notes

### Navigation Flow
1. **Home** - Trip list with carousel
2. **Trip Summary** - Click any trip → Summary page with action cards
3. **Expenses** - Click "Expenses" card → Full expense tracking

### State Management
- Local state with useState
- Trip data structure:
  ```typescript
  interface Trip {
    id: string;
    name: string;
    destination: string;
    startDate: string;
    endDate: string;
    participants: string[];
    totalExpenses: number;
    imageUrl: string;
  }
  ```

### Mobile Optimizations
- All components use MUI's `sx` prop for styling
- Active states (scale transform) instead of hover
- Touch-friendly 44px+ tap targets
- Sticky headers for context
- Swipeable carousel with react-slick

### MUI Spacing System
MUI uses 8px base unit:
- `p: 2` = 16px padding
- `gap: 1.5` = 12px gap
- `mb: 3` = 24px margin-bottom

### Colors for Feature Cards (TripSummary)
- Expenses: #1976d2 (blue)
- Invite: #9c27b0 (purple)
- Chat: #2196f3 (light blue)
- Places: #f44336 (red)
- Calendar: #ff9800 (orange)
- Map: #4caf50 (green)

### Expense Categories
Colors defined in ExpenseList.tsx:
- Food: #FF6B6B
- Accommodation: #4ECDC4
- Transportation: #45B7D1
- Activities: #FFA07A
- Shopping: #98D8C8
- Other: #95A5A6

## How to Use This Code

### Option 1: Direct Copy
1. Copy all files from `src/app/` directory
2. Ensure dependencies are installed (see package.json)
3. Import slick-carousel CSS in your entry point

### Option 2: Reference Implementation
Use this code as a reference for implementing in:
- React Native (for native iOS/Android)
- Flutter
- Swift/SwiftUI
- Any other framework

## Important Design Details

### FeaturedTripCard
- Image height: 160px
- 3-column grid for stats
- Shows "NOW" or "UPCOMING" badge
- Scale to 0.98 on tap

### TripSummary  
- Hero image: 220px with gradient overlay
- 6 action cards with colored icon boxes (48px)
- Each card has icon, title, description, chevron

### ExpenseList
- 40px avatars
- Category chips with custom colors
- Amount in primary color
- Inline delete button

### Carousel Settings
- Infinite: false
- Dots: true (custom styled)
- Arrows: false (mobile)
- SwipeToSlide: true

## Testing the Implementation
1. Create a trip
2. Add participants
3. Click trip → Should see Summary page
4. Click "Expenses" → Should see expense tracking
5. Add expenses and verify calculations
6. Check balance settlements

## Future Features (Placeholders)
- Invite Participants
- Trip Chat
- Places & Interests
- Itinerary Calendar
- Map View

These show toast notifications when clicked.
