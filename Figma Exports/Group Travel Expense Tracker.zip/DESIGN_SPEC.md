# TravelSplit - Design Specification

## Overview
Mobile-first expense tracking app for group travel, optimized for iOS.

## Color Palette
- Primary: #1976d2 (Blue)
- Success: #4caf50 (Green)
- Error: #f44336 (Red)
- Warning: #ff9800 (Orange)
- Purple: #9c27b0
- Text Primary: Default MUI
- Text Secondary: Default MUI

## Typography
Using Material-UI default typography with customizations:
- Headers: fontWeight 600
- Body text:Default
- Captions: fontSize 0.65rem - 0.85rem

## Layout
- Mobile-first design (375px base width)
- Sticky headers with blur/shadow
- 16px (2 spacing units) horizontal padding
- Border radius: 8px (1) for small cards, 16px (2) for main cards, 24px (3) for featured cards
- Card elevation: Minimal, using border and subtle shadow

## Key Screens

### 1. Home / Trip List
- Sticky header with app logo and "New" button
- Swipeable carousel for current/upcoming trips
  - Featured card: 160px image height
  - Compact stats in 3-column grid
  - Dots indicator below
- Collapsible "Past Trips" section
  - Horizontal card layout (120px image + content)

### 2. Trip Summary (Middle Layer)
- Hero image: 220px height with gradient overlay
- Back button on hero (white background)
- Trip title, destination, date range
- Avatar group for participants
- 6 action cards in vertical list:
  - 48px colored icon box
  - Title + description
  - Chevron right
  - Different colors per feature

### 3. Expense Tracking
- Sticky header with back button
- Compact stats card (3-column grid)
- Full-width tabs (Expenses, Balances, People)
- Full-width action buttons
- Expense cards:
  - 40px avatar
  - Title, payer, date
  - Amount in primary color
  - Delete button
  - Category chips with custom colors

## Component Patterns

### Cards
- borderRadius: 2 (16px)
- padding: 2 (16px)
- Active state: scale(0.98)
- No hover effects (mobile)

### Buttons
- Full-width for primary actions
- Size: small for header, medium/large for content
- py: 1.25-1.5 for comfortable tap targets

### Images
- objectFit: cover
- Rounded corners matching card

### Spacing
- Section spacing: mb: 3 (24px)
- Item spacing in lists: gap: 1.5-2 (12-16px)
- Tight spacing for mobile: gap: 1 (8px)

## Interactions
- Touch-optimized tap targets (minimum 44px)
- Active states instead of hover
- Swipe gestures for carousel
- Pull to refresh (future)
- Bottom sheet modals for forms

## Navigation
- Stack-based navigation
- Back buttons in headers
- No bottom nav (single flow)

## Data Display
- Compact number formatting (no decimals for large numbers)
- Date formatting: "MMM DD" or "MMM DD, YYYY"
- Currency: USD with $ prefix, 2 decimals where appropriate
